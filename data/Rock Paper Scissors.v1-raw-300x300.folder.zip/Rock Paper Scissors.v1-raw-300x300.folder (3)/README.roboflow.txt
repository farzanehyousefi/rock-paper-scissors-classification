
Rock Paper Scissors - v1 raw-300x300
==============================

This dataset was exported via roboflow.ai on March 19, 2020 at 6:20 PM GMT

It includes 2925 images.
Hands are annotated in folder format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


